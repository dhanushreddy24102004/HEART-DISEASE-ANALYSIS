data preparation
