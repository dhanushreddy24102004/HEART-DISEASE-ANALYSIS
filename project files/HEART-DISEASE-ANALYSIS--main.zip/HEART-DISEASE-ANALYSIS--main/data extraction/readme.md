data extration
